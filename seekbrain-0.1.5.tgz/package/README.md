# SeekBrain

[![Built on pi](https://img.shields.io/badge/Built_on-pi-24292f?style=flat-square)](https://github.com/earendil-works/pi)
![Node.js >=22.19](https://img.shields.io/badge/Node.js-%3E%3D22.19-339933?style=flat-square&logo=nodedotjs&logoColor=white)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg?style=flat-square)](LICENSE)

SeekBrain is an open-source, domain-specialized multi-agent framework for semi-autonomous neuroscience discovery. It transforms broad scientific questions and heterogeneous, multimodal brain data into hierarchical research plans, executable analysis pipelines, validated figures and statistics, and evidence-grounded conclusions—while keeping researchers in the loop.

<!--
Add the terminal demo as ./demo.gif, then replace this comment with:
<img src="./demo.gif" alt="SeekBrain terminal demo" />
-->

## News

- **2026-07-17** — SeekBrain was unveiled at the WAIC 2026 Science Frontiers Forum as a prototype system for a new neuroscience discovery paradigm built on the coordinated interaction of the biological brain, the AI computing brain (SeekBrain), and the digital brain (“生物脑–智算脑（SeekBrain）–数字脑”三脑联动).

## Get started

> [!NOTE]
> SeekBrain requires Node.js 22.19 or newer and a supported model-provider API key. Node.js 24 is recommended.

Download [seekbrain-0.1.5.tgz](./seekbrain-0.1.5.tgz), then install it from the directory containing the file:

```bash
npm install --global ./seekbrain-0.1.5.tgz
```

Then launch SeekBrain:

```bash
seekbrain
```

On first launch, SeekBrain guides you through model routing and literature-provider setup. Run `seekbrain --help` to see all commands and options.

## How it works

SeekBrain coordinates specialized agents around a traceable scientific workflow:

```text
research question + multimodal data
  → research planning and review
  → recipe-grounded analytical formulation
  → code generation and execution ↔ scientific validation
  → interpretation and evidence-grounded reporting
```

At its core, a co-evolving **Neuroscience Analysis Repertoire** crystallizes reusable methods from scientific papers and their associated open-source code, as well as researcher-validated execution trajectories. This grounds planning and execution in neuroscience-specific expertise while preserving researcher control and inspectable evidence.

## Paper

**SeekBrain: An Autonomous Multi-Agent Framework for Accelerating Neuroscience Discovery**

*Manuscript coming soon.*

The paper introduces BrainArena, an expert-annotated benchmark of 32 neuroscience analysis tasks derived from 10 source studies across five model organisms and seven analytical domains. Under the manuscript's reported evaluation setup, SeekBrain achieves a mean score of 75.5, compared with 64.1 for Claude Code and 58.1 for Codex, with its largest advantage in scientifically grounded result interpretation. Complementary real-world studies show researcher-steered analysis of freely moving larval zebrafish, revealing structured low-dimensional neural representations of behavioral types and distributed brain-wide tuning, and a SeekBrain-led, human-supervised reanalysis of the IBL mouse decision-making dataset, identifying a shared low-rank regional decoding-strength axis across five decoder maps.

## Documentation

- [Configuration](config/README.md)
- [Multi-round research](docs/seekbrain-multiround-research.md)
- [Contributing](CONTRIBUTING.md)

## Acknowledgments

SeekBrain is built on [pi](https://github.com/earendil-works/pi). We thank earendil-works and the pi contributors for their outstanding open-source work.

## License

SeekBrain is released under the [MIT License](LICENSE).
